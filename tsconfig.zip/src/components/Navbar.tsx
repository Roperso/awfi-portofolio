import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const navLinks = [
  { name: 'Portfolio', id: 'work' },
  { name: 'About', id: 'about' },
  { name: 'Services', id: 'services' },
  { name: 'Technologies', id: 'technologies' },
];

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleNavClick = (id: string) => {
    setIsOpen(false);
    if (location.pathname === '/') {
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      navigate(`/#${id}`);
    }
  };

  useEffect(() => {
    if (location.hash && location.pathname === '/') {
      const id = location.hash.replace('#', '');
      setTimeout(() => {
        document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    }
  }, [location]);

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? 'bg-[#0a0a0a]/90 backdrop-blur-md border-b border-[#242424] py-3.5 shadow-2xl shadow-black/40'
            : 'bg-[#0a0a0a]/50 backdrop-blur-sm border-b border-transparent py-5'
        }`}
      >
        <div className="section-container px-6 md:px-12 flex items-center justify-between">
          {/* Logo / Name */}
          <Link
            to="/"
            className="font-bold text-white text-[15px] tracking-tight hover:text-primary transition-colors flex items-center gap-2"
          >
            <span className="w-2 h-2 rounded-full bg-primary inline-block"></span>
            Awfi Muhammad
          </Link>

          {/* Desktop Nav Items */}
          <nav className="hidden md:flex items-center gap-1 bg-[#121212]/80 border border-[#242424] px-3 py-1.5 rounded-full">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => handleNavClick(link.id)}
                className="px-3.5 py-1 text-xs font-medium text-[#8e8e93] hover:text-white transition-colors rounded-full hover:bg-[#1a1a1a]"
              >
                {link.name}
              </button>
            ))}
            <Link
              to="/certificates"
              className={`px-3.5 py-1 text-xs font-medium transition-colors rounded-full ${
                location.pathname === '/certificates'
                  ? 'text-white bg-[#1a1a1a]'
                  : 'text-[#8e8e93] hover:text-white hover:bg-[#1a1a1a]'
              }`}
            >
              Certificates
            </Link>
          </nav>

          {/* Right Action */}
          <div className="hidden md:flex items-center">
            <button
              onClick={() => handleNavClick('contact')}
              className="bg-primary hover:bg-[#8b25f0] text-white px-4 py-2 rounded-md font-semibold text-xs transition-all flex items-center gap-1.5 shadow-md shadow-primary/20 hover:shadow-primary/40 active:scale-95 cursor-pointer"
            >
              Hire me <ArrowRight size={13} />
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            aria-label="Open menu"
            className="md:hidden text-white p-2 hover:bg-[#1a1a1a] rounded-lg transition-colors border border-[#242424]"
            onClick={() => setIsOpen(true)}
          >
            <Menu size={20} />
          </button>
        </div>
      </header>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] bg-[#0a0a0a]/98 backdrop-blur-2xl flex flex-col p-6"
          >
            <div className="flex justify-between items-center pb-6 border-b border-[#242424]">
              <Link
                to="/"
                onClick={() => setIsOpen(false)}
                className="font-bold text-white text-base flex items-center gap-2"
              >
                <span className="w-2 h-2 rounded-full bg-primary"></span>
                Awfi Muhammad
              </Link>
              <button
                onClick={() => setIsOpen(false)}
                className="text-white p-2 hover:bg-[#1a1a1a] rounded-lg border border-[#242424]"
              >
                <X size={20} />
              </button>
            </div>

            <div className="flex flex-col gap-2 mt-8">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className="text-left text-xl font-bold text-[#8e8e93] hover:text-white py-3 border-b border-[#242424]/60 transition-colors"
                >
                  {link.name}
                </button>
              ))}
              <Link
                to="/certificates"
                onClick={() => setIsOpen(false)}
                className="text-left text-xl font-bold text-[#8e8e93] hover:text-white py-3 border-b border-[#242424]/60 transition-colors"
              >
                Certificates
              </Link>
            </div>

            <div className="mt-auto pt-6">
              <button
                onClick={() => handleNavClick('contact')}
                className="w-full bg-primary hover:bg-[#8b25f0] text-white py-3.5 rounded-lg font-semibold text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-primary/20"
              >
                Hire me <ArrowRight size={16} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

import { useState } from 'react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { Award, ArrowLeft, ExternalLink, Eye, CheckCircle2 } from 'lucide-react';
import { certificates, type Certificate } from '@/data/certificates';
import GlowCard from '@/components/GlowCard';
import CertificateLightbox from '@/components/CertificateLightbox';

export default function Certificates() {
  const [selectedCert, setSelectedCert] = useState<Certificate | null>(null);

  return (
    <main className="min-h-screen pt-32 pb-24 px-6 md:px-12 lg:px-16 relative">
      {/* Background Soft Purple Glow */}
      <div
        className="absolute top-20 left-1/2 -translate-x-1/2 w-[500px] h-[500px] rounded-full pointer-events-none opacity-10 blur-[130px]"
        style={{
          background: 'radial-gradient(circle, #a855f7 0%, transparent 80%)',
        }}
      />

      <div className="section-container relative z-10">
        {/* Back Link */}
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-[#8e8e93] hover:text-white transition-colors mb-10 group"
        >
          <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform" />
          Back to portfolio
        </Link>

        {/* Header */}
        <div className="max-w-2xl">
          <div className="flex items-center gap-2 mb-3">
            <span className="w-2 h-2 rounded-full bg-primary"></span>
            <span className="t-label text-primary">Credentials & Events</span>
          </div>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="t-display text-white"
            style={{ fontSize: 'clamp(38px, 6vw, 64px)' }}
          >
            Certificates.
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-[#8e8e93] text-base md:text-lg mt-4 font-light leading-relaxed"
          >
            A collection of certifications, seminars, and professional learning experiences.
          </motion.p>
        </div>

        {/* Certificate Card Grid */}
        <div className="mt-14 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {certificates.map((cert, index) => (
            <motion.div
              key={cert.id}
              initial={{ opacity: 0, y: 25 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <GlowCard className="h-full flex flex-col justify-between rounded-xl overflow-hidden bg-[#121212] border border-[#242424] group">
                <div>
                  {/* Certificate Image Box / Clickable */}
                  <div
                    onClick={() => setSelectedCert(cert)}
                    className="aspect-video relative overflow-hidden bg-[#1a1a1a] cursor-pointer"
                  >
                    <img
                      src={cert.image}
                      alt={cert.title}
                      className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 text-white text-xs font-semibold backdrop-blur-xs">
                      <Eye size={16} /> Click to enlarge
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-3">
                      <span className="px-2.5 py-0.5 rounded text-[10px] font-mono uppercase tracking-wider bg-primary/10 text-primary border border-primary/20">
                        {cert.category}
                      </span>
                      {cert.year && (
                        <span className="text-[11px] font-mono text-[#8e8e93]">{cert.year}</span>
                      )}
                    </div>

                    <h3 className="t-heading text-lg text-white group-hover:text-primary transition-colors">
                      {cert.title}
                    </h3>

                    {cert.issuer && (
                      <p className="text-xs text-[#8e8e93] mt-2 font-mono flex items-center gap-1.5">
                        <CheckCircle2 size={13} className="text-primary" /> {cert.issuer}
                      </p>
                    )}

                    {cert.description && (
                      <p className="text-xs text-[#8e8e93] mt-3 leading-relaxed font-light">
                        {cert.description}
                      </p>
                    )}
                  </div>
                </div>

                {/* Card Action Footer */}
                <div className="p-6 pt-0 mt-2 flex items-center gap-3">
                  <button
                    onClick={() => setSelectedCert(cert)}
                    className="text-xs font-semibold text-primary hover:text-white transition-colors flex items-center gap-1 cursor-pointer"
                  >
                    View certificate &rarr;
                  </button>
                  {cert.verificationUrl && (
                    <a
                      href={cert.verificationUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-[#8e8e93] hover:text-white transition-colors flex items-center gap-1 ml-auto"
                    >
                      Verify <ExternalLink size={12} />
                    </a>
                  )}
                </div>
              </GlowCard>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Lightbox Modal */}
      <CertificateLightbox
        isOpen={selectedCert !== null}
        onClose={() => setSelectedCert(null)}
        title={selectedCert?.title ?? ''}
        image={selectedCert?.image ?? ''}
      />
    </main>
  );
}

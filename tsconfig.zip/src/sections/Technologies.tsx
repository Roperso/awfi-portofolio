import { motion } from 'motion/react';
import { Gamepad2, Hash, Code, Terminal, Figma, Database } from 'lucide-react';
import { technologies } from '@/data/skills';
import SectionHeading from '@/components/SectionHeading';

const iconMap: Record<string, React.ElementType> = {
  'gamepad-2': Gamepad2,
  hash: Hash,
  code: Code,
  terminal: Terminal,
  figma: Figma,
  database: Database,
};

export default function Technologies() {
  return (
    <section id="technologies" className="py-24 px-6 md:px-12 lg:px-16 text-center relative">
      <div className="section-container">
        <div className="max-w-xl mx-auto mb-12">
          <SectionHeading className="mx-auto">Technologies.</SectionHeading>
          <p className="text-[#8e8e93] text-sm mt-3 font-light">
            Core languages, frameworks, and creative software utilized in daily development.
          </p>
        </div>

        {/* 6-across Icon Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3.5 max-w-4xl mx-auto">
          {technologies.map((tech, index) => {
            const IconComponent = iconMap[tech.icon] || Code;
            return (
              <motion.div
                key={tech.name}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05, duration: 0.4 }}
                className="flex flex-col items-center justify-center gap-3 p-6 rounded-xl bg-[#121212] border border-[#242424] hover:border-primary/50 transition-all duration-200 group cursor-default"
              >
                <div className="w-12 h-12 rounded-xl bg-[#1a1a1a] flex items-center justify-center group-hover:bg-primary/10 transition-colors">
                  <IconComponent
                    size={24}
                    className="text-[#8e8e93] group-hover:text-primary transition-colors duration-200"
                  />
                </div>
                <span className="font-mono text-[11px] text-[#8e8e93] group-hover:text-white transition-colors duration-200 uppercase tracking-wider font-medium">
                  {tech.name}
                </span>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowRight, Sparkles } from 'lucide-react';
import { projects } from '@/data/projects';
import GlowCard from '@/components/GlowCard';
import SectionHeading from '@/components/SectionHeading';

export default function SelectedWork() {
  return (
    <section id="work" className="py-28 px-6 md:px-12 lg:px-16 relative">
      <div className="section-container">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-14 gap-4">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Sparkles size={14} className="text-primary" />
              <span className="t-label text-primary">Featured Portfolio</span>
            </div>
            <SectionHeading>Selected work.</SectionHeading>
          </div>
          <p className="text-[#8e8e93] text-sm md:text-base max-w-md font-light">
            Interactive digital experiences, software development, machine learning, and creative design systems.
          </p>
        </div>

        {/* Asymmetric Project Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {projects.map((project, index) => {
            const isFirst = index === 0;
            return (
              <motion.div
                key={project.slug}
                className={isFirst ? 'md:col-span-2' : 'col-span-1'}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ duration: 0.5, delay: index * 0.08 }}
              >
                <GlowCard className="h-full rounded-xl overflow-hidden group border border-[#242424] bg-[#121212]">
                  <Link to={`/projects/${project.slug}`} className="block relative h-full">
                    {/* Image Box */}
                    <div
                      className={`relative overflow-hidden bg-[#1a1a1a] ${
                        isFirst ? 'aspect-[21/9] md:aspect-[21/9]' : 'aspect-video'
                      }`}
                    >
                      <img
                        src={project.image}
                        alt={project.title}
                        className="w-full h-full object-cover object-center transition-transform duration-700 ease-out group-hover:scale-105"
                        loading="lazy"
                      />

                      {/* Subtle Dark Gradient Overlay */}
                      <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-transparent to-transparent opacity-80 group-hover:opacity-40 transition-opacity duration-300" />

                      {/* Category Badge on Image Top Left */}
                      <div className="absolute top-4 left-4 z-10">
                        <span className="px-3 py-1 rounded-md text-[10px] font-mono uppercase tracking-wider bg-[#0a0a0a]/80 backdrop-blur-md border border-[#242424] text-white">
                          {project.category}
                        </span>
                      </div>

                      {/* Year Badge Top Right */}
                      <div className="absolute top-4 right-4 z-10">
                        <span className="px-2.5 py-1 rounded-md text-[11px] font-mono text-[#8e8e93] bg-[#0a0a0a]/80 backdrop-blur-md border border-[#242424]">
                          {project.year}
                        </span>
                      </div>
                    </div>

                    {/* Card Content Footer */}
                    <div className="p-6 md:p-7 flex flex-col justify-between">
                      <div>
                        <h3 className="t-heading text-lg md:text-xl text-white group-hover:text-primary transition-colors flex items-center justify-between">
                          <span>{project.title}</span>
                          <ArrowRight
                            size={18}
                            className="text-[#8e8e93] group-hover:text-primary group-hover:translate-x-1.5 transition-all shrink-0 ml-2"
                          />
                        </h3>
                        <p className="text-[#8e8e93] text-sm mt-2.5 line-clamp-2 font-light leading-relaxed">
                          {project.description}
                        </p>
                      </div>

                      {/* Technologies Tags */}
                      <div className="flex flex-wrap gap-2 mt-5 pt-4 border-t border-[#242424]">
                        {project.technologies.map((tech) => (
                          <span
                            key={tech}
                            className="text-[11px] font-mono px-2.5 py-1 rounded bg-[#1a1a1a] text-[#8e8e93] border border-[#242424]/60"
                          >
                            {tech}
                          </span>
                        ))}
                        <span className="text-[11px] font-medium text-primary ml-auto flex items-center gap-1 group-hover:underline self-center">
                          View case study &rarr;
                        </span>
                      </div>
                    </div>
                  </Link>
                </GlowCard>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

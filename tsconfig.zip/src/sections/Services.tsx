import { motion } from 'motion/react';
import { services } from '@/data/skills';
import GlowCard from '@/components/GlowCard';
import SectionHeading from '@/components/SectionHeading';
import { Layout, Palette, Code2, ArrowUpRight } from 'lucide-react';

const serviceIcons = [Layout, Palette, Code2];

export default function Services() {
  return (
    <section id="services" className="py-28 px-6 md:px-12 lg:px-16 bg-[#121212] border-y border-[#242424] relative">
      <div className="section-container">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-14 gap-4">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="w-2 h-2 rounded-full bg-primary"></span>
              <span className="t-label text-primary">Capabilities</span>
            </div>
            <SectionHeading>What I do.</SectionHeading>
          </div>
          <p className="text-[#8e8e93] text-sm md:text-base max-w-md font-light">
            End-to-end design and engineering services tailored for digital products, brands, and interactive systems.
          </p>
        </div>

        {/* 3-Column Service Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {services.map((service, index) => {
            const Icon = serviceIcons[index] || Code2;
            return (
              <motion.div
                key={service.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <GlowCard className="p-8 h-full flex flex-col justify-between group rounded-xl bg-[#0a0a0a] border border-[#242424]">
                  <div>
                    {/* Icon & Category */}
                    <div className="flex items-center justify-between mb-6">
                      <div className="w-12 h-12 rounded-xl bg-[#1a1a1a] border border-[#242424] flex items-center justify-center group-hover:border-primary/40 group-hover:bg-primary/10 transition-colors">
                        <Icon size={22} className="text-[#8e8e93] group-hover:text-primary transition-colors" />
                      </div>
                      <ArrowUpRight
                        size={18}
                        className="text-[#8e8e93] group-hover:text-primary group-hover:translate-x-1 group-hover:-translate-y-1 transition-all"
                      />
                    </div>

                    <span className="t-label text-primary">{service.category}</span>
                    <h3 className="t-heading text-xl text-white mt-2 group-hover:text-primary transition-colors">
                      {service.name}
                    </h3>

                    <p className="text-[#8e8e93] text-sm mt-3.5 leading-relaxed font-light">
                      {service.description}
                    </p>
                  </div>

                  {/* Pricing Footer */}
                  <div className="mt-8 pt-5 border-t border-[#242424] flex items-center justify-between">
                    <span className="text-[11px] font-mono text-[#8e8e93] uppercase tracking-wider">
                      Pricing
                    </span>
                    <span className="text-xs font-mono text-white/90">
                      {service.price}
                    </span>
                  </div>
                </GlowCard>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

export interface Certificate {
  id: string;
  title: string;
  issuer: string;
  year: string;
  category: string;
  image: string;
  certificateId?: string;
  verificationUrl?: string;
  documentUrl?: string;
  description?: string;
}

export const certificates: Certificate[] = [
  {
    id: 'mos',
    title: 'Microsoft Office Specialist (MOS)',
    issuer: 'Microsoft',
    year: '2023',
    category: 'Certification',
    image: '/images/cert-mos.jpg',
    description: 'Demonstrated professional proficiency in advanced productivity software and document workflow standards.',
  },
  {
    id: 'it-specialist-data-analytics',
    title: 'IT Specialist — Data Analytics',
    issuer: 'Certiport / Pearson VUE',
    year: '2024',
    category: 'Certification',
    image: '/images/cert-data-analytics.jpg',
    description: 'Comprehensive validation in data manipulation, exploratory data analysis, visualization, and foundational predictive analytics.',
  },
  {
    id: 'gdg-bandung-iox-2026',
    title: 'Google Developer Group (GDG) Bandung — IOX 2026',
    issuer: 'Google Developer Group Bandung',
    year: '2026',
    category: 'Seminar / Community Event',
    image: '/images/cert-gdg.jpg',
    description: 'Participation in developer ecosystem keynote sessions, cutting-edge AI technology workshops, and developer networking.',
  },
];

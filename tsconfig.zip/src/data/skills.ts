export interface Technology {
  name: string;
  icon: string;
}

export const technologies: Technology[] = [
  { name: 'Unity', icon: 'gamepad-2' },
  { name: 'C#', icon: 'hash' },
  { name: 'C++', icon: 'code' },
  { name: 'Python', icon: 'terminal' },
  { name: 'Figma', icon: 'figma' },
  { name: 'SQL', icon: 'database' },
];

export interface Service {
  category: string;
  name: string;
  description: string;
  price: string;
}

export const services: Service[] = [
  {
    category: 'Design',
    name: 'UI/UX Design',
    description:
      'Designing clean and user-focused interfaces for websites and digital applications.',
    price: 'Starting from custom quote',
  },
  {
    category: 'Design',
    name: 'Graphic Design',
    description:
      'Creating visual assets, digital graphics, thumbnails, and creative materials based on project needs.',
    price: 'Starting from custom quote',
  },
  {
    category: 'Development',
    name: 'Software & Game Development',
    description:
      'Building software and interactive digital projects using modern programming tools and development workflows.',
    price: 'Starting from custom quote',
  },
];

export const credentialChips: string[] = [
  'Informatics Student',
  'Software Developer',
  'Creative Designer',
  'Freelance Experience',
  'Team Leadership',
  'Open to Opportunities',
];

export const heroTechLogos: Technology[] = [
  { name: 'Unity', icon: 'gamepad-2' },
  { name: 'Figma', icon: 'figma' },
  { name: 'Python', icon: 'terminal' },
  { name: 'React', icon: 'atom' },
];

export const aboutToolsGrid: Technology[] = [
  { name: 'Unity', icon: 'gamepad-2' },
  { name: 'Figma', icon: 'figma' },
  { name: 'Python', icon: 'terminal' },
  { name: 'C#', icon: 'hash' },
  { name: 'C++', icon: 'code' },
  { name: 'HTML', icon: 'globe' },
  { name: 'CSS', icon: 'palette' },
  { name: 'SQL', icon: 'database' },
];
